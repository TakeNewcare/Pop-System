﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Operations_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //chart2.Series[0].Points[0].AxisLabel = "Line 1";
            //chart2.Series[0].Points[1].AxisLabel = "Line 2";
            //chart2.Series[0].Points[2].AxisLabel = "Line 3";
            //chart2.Series[0].Points[3].AxisLabel = "Line 4";

  

        }
    }
}
